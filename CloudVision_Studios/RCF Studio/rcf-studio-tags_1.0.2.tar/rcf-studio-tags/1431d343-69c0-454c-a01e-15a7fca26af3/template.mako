<%
import copy
# If the developer wants to see the container details of the script. 
# Default debug setting is False. The info can be seen in `view build details` after clicking `review Workspace`
debug = False

def applyIndentation(content: str, indent=3, level=0):
    '''
    return: formatted multiline strings with indentation
    '''
    contentList = content.splitlines()
    res = ''
    indentation = ' ' * (indent * level)
    for l in contentList:
        newL = indentation + l + '\n'
        res += newL
    return res.rstrip()

try:
   codeUnitsData = {codeUnit['unitName']: applyIndentation(codeUnit['unitContent'], level=2)
                    for codeUnit in codeUnits}
   deviceToUnits = {}
   for devCodeUnit in devCodeUnits.inputs:
      for device in devCodeUnit['devices']:
         if device in deviceToUnits:
            deviceToUnits[device].extend(devCodeUnit['inputs']['devAssignments']['devAssignedUnits'])
         else:
            deviceToUnits[device] = devCodeUnit['inputs']['devAssignments']['devAssignedUnits'].copy()
except TypeError:
   codeUnitsData = {}
   deviceToUnits = {}
%>

%if debug:
! ${codeUnitsData}
!
! ${devCodeUnits.inputs}
!
! ${deviceToUnits}
%endif


%if ctx.getDevice().id in deviceToUnits and len(deviceToUnits[ctx.getDevice().id]) > 0:
router general
   control-functions
%   for unitName in deviceToUnits[ctx.getDevice().id]:
      code unit ${ unitName }
${ codeUnitsData[unitName] }
      EOF
%   endfor 
%endif

